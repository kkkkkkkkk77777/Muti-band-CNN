import torch
import numpy as np
from scipy.io import loadmat

def feature4D(data):
    data = data.transpose([0, 2, 1])
    N = data.shape[0]


    img_rows, img_cols, num_chan = 9, 9, 5
    data_4d = np.zeros((N, img_rows, img_cols, num_chan))
    # print("data_4d.shape :", data_4d.shape)

    # channels = ['FT7', 'FT8', 'T7', 'T8', 'TP7', 'TP8', 'CP1', 'CP2',
    #             'P1', 'PZ', 'P2', 'PO3', 'POZ', 'PO4', 'O1', 'OZ', 'O2']

    data_4d[:, 0, 3, :] = data[:, 0, :]

    data_4d[:, 0, 5, :] = data[:, 1, :]

    data_4d[:, 2, 2, :] = data[:, 2, :]

    data_4d[:, 2, 6, :] = data[:, 3, :]

    data_4d[:, 2, 0, :] = data[:, 4, :]

    data_4d[:, 2, 8, :] = data[:, 5, :]

    data_4d[:, 4, 2, :] = data[:, 6, :]

    data_4d[:, 4, 6, :] = data[:, 7, :]

    data_4d[:, 4, 0, :] = data[:, 8, :]

    data_4d[:, 4, 8, :] = data[:, 9, :]

    data_4d[:, 6, 2, :] = data[:, 10, :]

    data_4d[:, 6, 6, :] = data[:, 11, :]

    data_4d[:, 6, 0, :] = data[:, 12, :]

    data_4d[:, 6, 8, :] = data[:, 13, :]

    data_4d[:, 8, 3, :] = data[:, 14, :]

    data_4d[:, 8, 5, :] = data[:, 15, :]
    data_4d = data_4d.transpose([0, 3, 1, 2])
    # print("data_4d: ", data_4d.shape)
    return data_4d

