import torch.nn as nn
import torch
from torch.autograd import Variable
import numpy as np
import torch.nn.functional as F
import torch.optim as optim
import torch.utils.data as Data



class ScaledDotProductAttention(nn.Module):
    def __init__(self, d_k):
        super(ScaledDotProductAttention, self).__init__()
        self.d_k = d_k
        self.n_head = 16

    def forward(self, Q, K, V):
        '''
        Q: [batch_size, n_heads, len_q, d_k]
        K: [batch_size, n_heads, len_k, d_k]
        V: [batch_size, n_heads, len_v(=len_k), d_v]
        attn_mask: [batch_size, n_heads, seq_len, seq_len]
        '''
        scores = torch.matmul(Q, K.transpose(-1, -2)) / np.sqrt(
            self.d_k)  # scores : [batch_size, n_heads, len_q, len_k]
        # scores.masked_fill_(attn_mask, -1e9) # Fills elements of self tensor with value where mask is True.
        # print(scores.shape)
        attn = nn.Softmax(dim=-1)(scores)
        context = torch.matmul(attn, V)  # [batch_size, n_heads, len_q, d_v]
        return context


class MultiHeadAttention(nn.Module):
    def __init__(self, n_heads, d_model):
        super(MultiHeadAttention, self).__init__()
        self.h_dim = d_model // n_heads
        self.n_heads = n_heads
        self.d_model = d_model
        self.W_Q = nn.Linear(d_model, self.h_dim * n_heads, bias=False)
        self.W_K = nn.Linear(d_model, self.h_dim * n_heads, bias=False)
        self.W_V = nn.Linear(d_model, self.h_dim * n_heads, bias=False)
        self.fc = nn.Linear(n_heads * self.h_dim, d_model, bias=False)

    def forward(self, input_Q, input_K, input_V):
        '''
        input_Q: [batch_size, len_q, d_model]
        input_K: [batch_size, len_k, d_model]
        input_V: [batch_size, len_v(=len_k), d_model]
        attn_mask: [batch_size, seq_len, seq_len]
        '''
        residual, batch_size, len = input_Q, input_Q.size(0), input_Q.size(1)

        # (B, S, D) -proj-> (B, S, D_new) -split-> (B, S, H, W) -trans-> (B, H, S, W)
        Q = self.W_Q(input_Q)  # Q: [batch_size, n_heads, len_q, d_k]
        K = self.W_K(input_K)  # K: [batch_size, n_heads, len_k, d_k]
        V = self.W_V(input_V)  # V: [batch_size, n_heads, len_v(=len_k), d_v]

        # context: [batch_size, n_heads, len_q, d_v], attn: [batch_size, n_heads, len_q, len_k]
        context = ScaledDotProductAttention(self.h_dim)(Q, K, V)
        # print(context.shape)
        output = self.fc(context)  # [batch_size, len_q, d_model]

        return nn.LayerNorm(self.d_model)(output + residual)


class PoswiseFeedForwardNet(nn.Module):
    def __init__(self, d_model, d_ff):
        super(PoswiseFeedForwardNet, self).__init__()
        self.d_model = d_model
        self.fc = nn.Sequential(
            nn.Linear(d_model, d_ff, bias=False),
            nn.ReLU(),
            nn.Linear(d_ff, d_model, bias=False)
        )

    def forward(self, inputs):

        residual = inputs
        output = self.fc(inputs)
        return nn.LayerNorm(self.d_model)(output + residual)


class EncoderLayer(nn.Module):
    def __init__(self, n_heads, d_model, d_ff):
        super(EncoderLayer, self).__init__()
        self.enc_self_attn = MultiHeadAttention(n_heads, d_model)
        self.pos_ffn = PoswiseFeedForwardNet(d_model, d_ff)

    def forward(self, enc_input1, enc_input2):


        enc_outputs = self.enc_self_attn(enc_input1, enc_input2, enc_input2)
        enc_outputs = self.pos_ffn(enc_outputs)
        return enc_outputs


class Cross(nn.Module):
    def __init__(self, n_layers=2, n_heads=1, d_model=9, d_ff=32):
        super(Cross, self).__init__()
        self.layers = nn.ModuleList([EncoderLayer(n_heads, d_model, d_ff) for _ in range(n_layers)])

    def forward(self, enc_input1, enc_input2):
        global enc
        enc_outputs1 = enc_input1
        enc_outputs2 = enc_input2
        for layer in self.layers:
            enc = layer(enc_outputs1, enc_outputs2)
        return enc
if __name__ == '__main__':
    x1 = torch.rand(32, 320, 9, 9).cuda()
    x2 = torch.rand(32, 320, 9, 9).cuda()
    model = Cross().cuda()
    ma = model(x1, x2)
    print(ma.shape)