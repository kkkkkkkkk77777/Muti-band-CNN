
import math
import os
import pandas as pd
import numpy as np
from scipy.io import loadmat
from scipy.signal import butter, lfilter
from collections import Counter
from tqdm import tqdm
from DE_4D_Feature import *

def butter_bandpass(lowcut, highcut, fs, order=5):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return b, a

def normalization(data):
    min_val = np.min(data, axis=0)
    max_val = np.max(data, axis=0)
    data = (data - min_val) / (max_val - min_val)
    return data

def normalize(data):
    mean = np.mean(data)
    std = np.std(data)
    data = (data - mean) / std
    return data
def butter_bandpass_filter(data, lowcut, highcut, fs, order=5):
    b, a = butter_bandpass(lowcut, highcut, fs, order=order)
    y = lfilter(b, a, data)
    return y
def calculate_DE(saw_EEG_signal):
    variance = np.var(saw_EEG_signal, ddof=1)
    return math.log(2 * math.pi * math.e * variance) / 2
def label_pro(data, label, split, overlap):
    stride = int(split * (1 - overlap))
    num_sample = int(data.shape[0] / stride) - 1
    # num_sample = int(data.shape[0] / stride)
    temp_de = np.empty([data.shape[1], 5, num_sample])
    all_label = np.empty([num_sample])
    frequency = 1000
    for channel in range(data.shape[1]):
        signal = data[:, channel]
        delta = butter_bandpass_filter(signal, 1, 4,   frequency, order=3)
        theta = butter_bandpass_filter(signal, 4, 8,   frequency, order=3)
        alpha = butter_bandpass_filter(signal, 8, 14,  frequency, order=3)
        beta = butter_bandpass_filter(signal, 14, 31, frequency, order=3)
        gamma = butter_bandpass_filter(signal, 31, 51, frequency, order=3)
        delta = normalization(delta)
        theta = normalization(theta)
        alpha = normalization(alpha)
        beta = normalization(beta)
        gamma = normalization(gamma)
        DE_delta = np.zeros(shape=[0], dtype=float)
        DE_theta = np.zeros(shape=[0], dtype=float)
        DE_alpha = np.zeros(shape=[0], dtype=float)
        DE_beta = np.zeros(shape=[0], dtype=float)
        DE_gamma = np.zeros(shape=[0], dtype=float)
        for index in range(0, data.shape[0] - split + 1, stride):
            DE_delta = np.append(DE_delta, calculate_DE(delta[index:index + split]))
            DE_theta = np.append(DE_theta, calculate_DE(theta[index:index + split]))
            DE_alpha = np.append(DE_alpha, calculate_DE(alpha[index:index + split]))
            DE_beta = np.append(DE_beta, calculate_DE(beta[index:index + split]))
            DE_gamma = np.append(DE_gamma, calculate_DE(gamma[index:index + split]))
        temp_de[channel]=np.stack([DE_delta, DE_theta, DE_alpha, DE_beta, DE_gamma])
    temp_trial_de = temp_de.transpose([2, 1, 0])
    j = 0
    for i in range(0, data.shape[0] - split + 1, stride):
        index_label = label[i:i + split]
        max_label = max(Counter(index_label), key=Counter(index_label).get)
        all_label[j] = max_label
        j += 1
    return temp_trial_de, all_label

filePathdata = 'C:\\Users\\Desktop\\'
fold = os.listdir(filePathdata)
split = 50
overlap = 0.5
sub0_data = []
all_data = []
channel = range(2, 18)
#channel = [2, 4, 6]
num = len(channel)
all_alldata = np.empty([0, 5, num])
all_alllabel = np.empty([0, ])
target_labels = [3, 5]

if not os.path.exists('data'):
    os.makedirs('data')
for i in tqdm(range(len(fold))):
    fold_path = os.path.join(filePathdata, fold[i])
    file = os.listdir(fold_path)
    alldata = np.empty([0, 5, num])
    alllabel = np.empty([0, ])
    if not os.path.exists(f'./data0/sub{i + 1}'):
        os.makedirs(f'./dataq/sub{i + 1}')
    for j in range(len(file)):
        file_path = os.path.join(fold_path, file[j])
        data = pd.read_csv(file_path, header=None).to_numpy()[:, channel]
        label = pd.read_csv(file_path, header=None).to_numpy()[:, 1]
        marker = np.where((label == 3) | (label == 5) )

        selected_indices = []


        for value in [3, 5]:

            indices = marker[label[marker] == value]

            if len(indices) <= 2500:
                selected_indices.extend(indices)
            else:
                selected_indices.extend(indices[:2500])


        selected_indices = np.array(selected_indices)

        data = data[selected_indices ]
        label = label[selected_indices ]
        trial_de, all_label = label_pro(data, label, split, overlap)
        trial_de = feature4D(trial_de)
        sub_dict = {'data': trial_de, 'label': all_label}
        np.save(('./data/sub{}/trail{}.npy'.format(i+1,j)), sub_dict)
        # alldata = np.concatenate([alldata, temp_trial_de], axis=0)
        # alllabel = np.concatenate([alllabel, all_label], axis=0)
    # sub_dict = {'data': alldata, 'label': alllabel}
    # np.save(('./sub{}.npy'.format(i)), sub_dict)
    # all_alldata = np.concatenate([all_alldata, alldata], axis=0)
    # all_alllabel = np.concatenate([all_alllabel, alllabel], axis=0)
# print('all_alldata:', all_alldata.shape, 'all_alllabel:', all_alllabel.shape)
# all_dict = {'data': all_alldata, 'label': all_alllabel}
# np.save(('./all_de100.npy'), all_dict)
