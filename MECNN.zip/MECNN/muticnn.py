import numpy as np
import torch
from torch import nn
from torch.nn import init
import torch.nn.functional as F
from crosstransformer import Cross2
from transformer_only import Cross

def mish(x):
    return x*(torch.tanh(F.softplus(x)))

class SEAttention(nn.Module):

    def __init__(self, channel=512,reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )


    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode='fan_in')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.normal_(m.weight, std=0.001)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)


class spatialAttention(nn.Module):
    def __init__(self, input_channels):
        super(spatialAttention, self).__init__()
        self.kernel_size = 7

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.conv = nn.Conv2d(in_channels=input_channels * 2,
                              out_channels=1,
                              kernel_size=self.kernel_size,
                              stride=1,
                              padding=self.kernel_size // 2,
                              bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_pool = self.avg_pool(x)
        max_pool = self.max_pool(x)

        concat = torch.cat((avg_pool, max_pool), dim=1)

        cbam_feature = self.conv(concat)
        cbam_feature = self.sigmoid(cbam_feature)

        return x * cbam_feature


class ChannelAttention(nn.Module):
    def __init__(self, channel, reduction):
        super().__init__()
        self.maxpool = nn.AdaptiveMaxPool2d(1)
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.se = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(channel // reduction, channel, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_result = self.maxpool(x)
        avg_result = self.avgpool(x)
        max_out = self.se(max_result)
        avg_out = self.se(avg_result)
        output = self.sigmoid(max_out + avg_out)
        return output

class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size=kernel_size, padding=kernel_size // 2)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_result, _ = torch.max(x, dim=1, keepdim=True)
        avg_result = torch.mean(x, dim=1, keepdim=True)
        result = torch.cat([max_result, avg_result], dim=1)
        output = self.conv(result)
        output = self.sigmoid(output)
        return output

class CBAMBlock(nn.Module):

    def __init__(self, channel, reduction=16, kernel_size=7):
        super().__init__()
        self.ca = ChannelAttention(channel=channel, reduction=reduction)
        self.sa = SpatialAttention(kernel_size=kernel_size)

    def forward(self, x):
        b, c, _, _ = x.size()
        residual = x
        out = x * self.ca(x)
        out = out * self.sa(out)

        return out+residual

class Conv2d_res(nn.Module):

    def __init__(self, in_channels, out_channels, residual=True, kernel_size=3):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=kernel_size//2, stride=2),
            nn.BatchNorm2d(out_channels),
        )
        if not residual:
            self.residual = lambda x: 0
        else:
            self.residual = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=2),
                nn.BatchNorm2d(out_channels),
            )

    def forward(self, x):
        res = self.residual(x)
        x = self.conv(x)
        return mish(x + res)

class SE_CNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=32, kernel_size=(3, 3), padding='same')
        self.bn1 = torch.nn.BatchNorm2d(32)
        self.SE1 = SEAttention(channel=32, reduction=16)

        self.conv2 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=(2, 2), padding='same')
        self.bn2 = torch.nn.BatchNorm2d(64)
        self.SE2 = SEAttention(channel=64, reduction=16)

        self.conv3 = nn.Conv2d(in_channels=64, out_channels=64, kernel_size=(1, 1), padding='same')
        self.bn3 = torch.nn.BatchNorm2d(64)
        self.SE3 = SEAttention(channel=64, reduction=16)

        nn.init.kaiming_uniform_(self.conv1.weight, mode='fan_in')
        nn.init.kaiming_uniform_(self.conv2.weight, mode='fan_in')
        nn.init.kaiming_uniform_(self.conv3.weight, mode='fan_in')

        self.prelu = nn.PReLU()


    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.prelu(x)
        # x = x.unsqueeze(1).transpose(1,2)
        x = self.SE1(x)
        # print(x.shape)

        x = torch.squeeze(x)
        x = self.conv2(x)
        x = self.bn2(x)
        x = self.prelu(x)
        # x = x.unsqueeze(1).transpose(1, 2)
        x = self.SE2(x)

        x = torch.squeeze(x)
        x = self.conv3(x)
        x = self.bn3(x)
        x = self.prelu(x)
        # x = x.unsqueeze(1).transpose(1, 2)
        x = self.SE3(x)
        return x

class Muti_CNN(nn.Module):
    def __init__(self, in_channels, class_num):
        super().__init__()
        self.secnn1 = SE_CNN()
        self.secnn2 = SE_CNN()
        self.secnn3 = SE_CNN()
        self.secnn4 = SE_CNN()
        self.secnn5 = SE_CNN()

        self.attention = spatialAttention(input_channels=320)
        # self.cbam = CBAMBlock(320)
        # self.cross = Cross2(320, 81)
        self.cross = Cross()

        self.residual = nn.Sequential(  # XT结构残差
            nn.Conv2d(in_channels, 320, kernel_size=1),
            nn.BatchNorm2d(320),
        )

        self.decode = nn.Sequential(
            # Conv2d_res(320, 320),  # T, V -> T//2, V//2
            Conv2d_res(320, 256),  # T, V -> T//2, V//2
            Conv2d_res(256, 128),  # T, V -> T//2, V//2
            Conv2d_res(128, 32),  # T, V -> T//2, V//2
        )
        self.fcn = nn.Conv2d(32, class_num, kernel_size=1)
        # self.SoftMax = nn.Softmax(dim=1)

    def forward(self, x):

        x1 = self.secnn1(x[:, 0:1, :, :])
        # print(x1.shape)
        x2 = self.secnn2(x[:, 1:2, :, :])
        x3 = self.secnn3(x[:, 2:3, :, :])
        x4 = self.secnn4(x[:, 3:4, :, :])
        x5 = self.secnn5(x[:, 4:5, :, :])

        x = torch.cat([x1, x2, x3, x4, x5], 1)
        # print(x.shape)

        # x = x.view(-1, 320, 81)
        x = self.cross(x, x)

        # x = self.cbam(x)
        # print(x.shape)
        # 解码
        x = self.decode(x)
        # print(x.shape)
        x = F.avg_pool2d(x, x.size()[2:])
        # print(x.shape)
        x = self.fcn(x)
        # print(x.shape)
        x = x.view(x.size(0), -1)

        return x




if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    x = torch.rand(32, 5, 9, 9).to(device)
    model = Muti_CNN(1, 5).to(device)

    y = model(x)

    print(y.shape)