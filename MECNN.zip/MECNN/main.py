import pandas as pd
import torch
import torch.nn as nn
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import torch.utils.data as data
from muticnn1 import *
from visualization import *
import os
import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="torch.nn.modules.conv")
from torch.utils.data import DataLoader,TensorDataset


def cuda(xs):
    if torch.cuda.is_available():
        if not isinstance(xs, (list, tuple)):
            return xs.cpu()
        else:
            return [x.cpu() for x in xs]
    else:
        return xs

def train(model, trainloader, criterion, optimizer, device):
    model.train()

    total = 0
    correct = 0
    running_loss = 0.0

    for i, data in enumerate(trainloader, 0):
        inputs, labels = data
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
        running_loss += loss.item()

    train_acc = 100 * (correct / total)

    return running_loss / len(trainloader), train_acc



def test(model, testloader, criterion, device):
    model.eval()
    correct = 0
    total = 0
    running_loss = 0.0
    all_pred = []
    all_true = []
    all_outputs = []
    with torch.no_grad():
        for data in testloader:
            images, labels = data
            images, labels = images.to(device), labels.to(device)
            all_true.extend(labels.cpu().tolist())
            outputs = model(images)
            all_outputs.append(outputs)

            _, predicted = torch.max(outputs.data, 1)

            all_pred.extend(predicted.cpu().tolist())
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

            loss = criterion(outputs, labels)
            running_loss += loss.item()
    all_outputs = torch.cat(all_outputs, dim=0)
    test_acc = 100 * correct / total
    return running_loss / len(testloader), test_acc, all_true, all_pred, all_outputs


class MyDataset(data.Dataset):

    def __init__(self, x1, y):
        self.x1 = x1
        self.y = y

    def __getitem__(self, index):
        input_emg = self.x1[index]
        target = self.y[index]
        return input_emg, target

    def __len__(self):
        return len(self.x1)


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    from sklearn.model_selection import KFold
    num_epochs = 50
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    result_dir = './result'
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)

    sub_fold = os.listdir(path)

    for j in sub_fold:
        trail_path = os.path.join(path, j)

        if not os.path.isdir(trail_path):
            continue
        trail_fold = os.listdir(trail_path)
        all_all_outputs_max = []
        all_all_true_max = []
        all_trail_acc = []

        for i in range(len(trail_fold)):
            # print(len(trail_fold))
            data = np.load('{}/{}'.format(trail_path, trail_fold[i]), allow_pickle=True).item()  # 时频
            alldata = data['data']
            alllabel = data['label']

            alllabel = np.where(alllabel == 3, 0, np.where(alllabel == 6, 1, np.where(alllabel == 8, 2, np.where(alllabel == 17, 3, np.where(alllabel == 19, 4, alllabel)))))
            num_folds = 10
            print(alldata.shape)
            print(alllabel.shape)
            kf = KFold(n_splits=num_folds, shuffle=True, random_state=40)
            for fold, (train_index, test_index) in enumerate(kf.split(alldata)):
                model = Muti_CNN(1, 5).to(device)
                # model = CNN().to(device)
                criterion = nn.CrossEntropyLoss().to(device)
                optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=0.0001)
                scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.7)

                train_x, test_x = alldata[train_index], alldata[test_index]
                train_y, test_y = alllabel[train_index], alllabel[test_index]

                # 转换成tensor
                X_train = torch.Tensor(train_x)
                X_val = torch.Tensor(test_x)

                Y_train = torch.Tensor(train_y)
                Y_val = torch.Tensor(test_y)


                traindatasets = MyDataset(X_train.float(), Y_train.long())  # 初始化
                testdatasets = MyDataset(X_val.float(), Y_val.long())
                # train_loader = DataLoader(traindatasets, batch_size=32, shuffle=True, drop_last=True)
                # test_loader = DataLoader(testdatasets, batch_size=32, shuffle=False, drop_last=True)
                train_loader = DataLoader(traindatasets, batch_size=20, shuffle=True)
                test_loader = DataLoader(testdatasets, batch_size=20, shuffle=False)
                all_true=[]
                all_pred=[]
                train_losses = []
                test_losses = []
                train_accuracies = []
                test_accuracies = []
                all_true_max = []
                all_pred_max = []
                all_outputs_max = []
                test_acc_max = 0
                print('start')
                for epoch in range(num_epochs):
                    train_loss, train_acc = train(model, train_loader, criterion, optimizer, device)
                    test_loss, test_acc, all_true, all_pred, all_outputs = test(model, test_loader, criterion, device)
                    train_losses.append(train_loss)
                    test_losses.append(test_loss)
                    train_accuracies.append(train_acc)
                    test_accuracies.append(test_acc)
                    # print("第%d轮的学习率：%f" % (epoch + 1, optimizer.param_groups[0]['lr']))

                    print('Epoch [{}/{}], lr:{},Train Loss: {:.4f}, Test Loss: {:.4f}, Train Accuracy: {:.2f}%, Test Accuracy: {:.2f}% '
                          .format(epoch + 1, num_epochs, optimizer.param_groups[0]['lr'], train_loss, test_loss, train_acc, test_acc))
                    scheduler.step()
                    if test_acc_max < test_acc:
                        test_acc_max = test_acc
                        all_true_max = all_true
                        all_pred_max = all_pred
                        all_outputs_max = all_outputs

                all_trail_acc.append(np.max(test_accuracies))

                print("Max Test Accuracy: {:.2f}%".format(np.max(test_accuracies)))
                if fold == 0:
                    break

            #all_all_outputs_max.append(all_outputs_max)
            #all_all_true_max.append(all_true_max)
            #label = ['8hz', '9.6hz', '12hz', '13.3hz','15hz']
           # save_path1 =
           # save_path2 =
           #  save_path3 =
            tSNE_plot(all_outputs_max, all_true_max, 2, 5, label, 50, save_path1)
            con_matrix(all_true_max, all_pred_max, label, 5, save_path2)
            roc_plot(all_outputs_max, all_true_max, label, save_path3)

        # all_dict = {'output': all_all_outputs_max, 'true': all_all_true_max}
        # np.save((f'./parameters/{j}.npy'), all_dict)

        ave_acc = np.mean(all_trail_acc)
        sub_trail = np.append(all_trail_acc, ave_acc).reshape(-1, 1)
        writer = pd.ExcelWriter(os.path.join(result_dir, f'{j}.xlsx'), engine='openpyxl')
        label = [f'sub_trail_{i + 1}' for i in range(len(trail_fold))] + ['ave_trail']

        df = pd.DataFrame(sub_trail, columns=[f'{j}'])
        df.insert(0, 'Label', label)

        df.to_excel(writer, index=False)

        writer.close()

    # plt.figure(figsize=(10, 5))
    # plt.plot(train_losses, label='Training Loss')
    # plt.plot(test_losses, label='Test Loss')
    # plt.title('Training and Test Loss')
    # plt.xlabel('Epochs')
    # plt.ylabel('Loss')
    # plt.legend()
    # plt.show()
    #
    # plt.figure(figsize=(10, 5))
    # plt.plot(train_accuracies, label='Training acc')
    # plt.plot(test_accuracies, label='Test acc')
    # plt.title('Training and Test acc')
    # plt.xlabel('Epochs')
    # plt.ylabel('Acc')
    # plt.legend()
    # plt.show()
